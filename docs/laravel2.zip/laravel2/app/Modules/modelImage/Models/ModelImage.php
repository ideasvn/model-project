<?php

namespace App\Modules\ModelImage\Models;

use Illuminate\Database\Eloquent\Model;

class ModelImage extends Model
{
    protected $table='model_image';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [

    ];
}
