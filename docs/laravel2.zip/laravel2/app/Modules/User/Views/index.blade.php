<?php
/**
 * Created by PhpStorm.
 * User: tungtv
 * Date: 7/1/2016
 * Time: 10:08 AM
 */
?>
<html>
<head>
    <test></test>
</head>
<body>
tungtvda
</body>
</html>
